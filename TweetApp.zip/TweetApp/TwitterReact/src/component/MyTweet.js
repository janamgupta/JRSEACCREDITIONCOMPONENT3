import axios from "axios";
import React from "react";
import { Container } from "react-bootstrap";
import NavBar from "./Nav";
import Tweet from "./Tweet";
import Logo from '../assets/Usericon1.png';
import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
class MyTweet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: {
                main: '',
                viewTweet: '',
                viewUser: '',
                resetPass: '',
                myTweets: 'active'
            },
            tweets: []
        }
    }

    componentDidMount() {
        let isLoggedIn = localStorage.getItem("isLoggedIn");
        if (isLoggedIn === 'false') {
            this.props.history.push('/login');
        } else {
            this.getTweets();
        }
    }

    getTweets() {
        let loginId = localStorage.getItem("username")
        axios.get('http://15.207.116.62:8092/api/v1.0/tweets/myTweet', { params: { loginId: loginId } })
            .then((response) => {
                this.setState({ tweets: response.data });
                console.log(this.state.tweets);
            }, (error) => {
                console.log(error);
            });
    }

    deleteTweet(tweet) {
        let loginId = localStorage.getItem("username")
        console.log("tweetID"+tweet.tweetId)
        axios.delete(`http://15.207.116.62:8092/api/v1.0/tweets/delete/${tweet.tweetId}`)
            .then((response) => {
                if(response.data === "success"){
                    this.setState({
                        tweets: this.state.tweets.filter(Tweet => Tweet.tweetId !== tweet.tweetId)
                    });
                }
            }, (error) => {
                console.log(error);
            });
    }
    render() {
        return (
            <div>
                <NavBar active={this.state.active} />
                <Container className="mt-5">
                    {this.state.tweets.length !== 0 ?
                        this.state.tweets.map((tweet) => {
                            return <div className="row justify-content-center align-self-center">
                                <div className="card tweetcard mb-3" style={{ maxWidth: "540px" }}>
                                    <div className="row no-gutters">
                                        <div className="col-md-12">
                                            <Tweet tweetInfo={tweet} profile={Logo} history={this.props.history} isReply={false}></Tweet>
                                        </div></div>
                                    <div className="mb-2 text-center"><button className="btn btn-outline-danger btn-sm shadow-none" type="button" onClick={() => this.deleteTweet(tweet)}><DeleteOutlineOutlinedIcon className="deleteBtn" fontSize="small"></DeleteOutlineOutlinedIcon><span> Delete </span></button></div>
                                </div></div>
                        })
                        : <div className="row justify-content-center align-self-center"><p className="h4 mb-4 text-center newposttext">You dont't have any tweet.</p></div>
                    }
                </Container>
            </div>
        );
    }
}
export default MyTweet;