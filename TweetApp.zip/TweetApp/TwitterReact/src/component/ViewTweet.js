import axios from "axios";
import React from "react";
import { Container } from "react-bootstrap";
import NavBar from "./Nav";
import Tweet from "./Tweet";
import Logo from '../assets/Usericon1.png';
import Logo2 from '../assets/Usericon2.png';
import Logo3 from '../assets/woman.png';

class ViewTweet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: {
                main: '',
                viewTweet: 'active',
                viewUser: '',
                resetPass: '',
                myTweets: ''
            },
            tweets: [],
            profilePic: [Logo, Logo2, Logo3]
        }
    }
    componentDidMount() {
        let isLoggedIn = localStorage.getItem("isLoggedIn");
        if (isLoggedIn === 'false') {
            this.props.history.push('/login');
        } else {
            this.getTweets();
        }
    }

    getTweets() {
        axios.get('http://15.207.116.62:8092/api/v1.0/tweets/gettweets')
            .then((response) => {
                this.setState({ tweets: response.data });
                console.log(this.state.tweets);
            }, (error) => {
                console.log(error);
            });
    }
    render() {
        return (
            <div>
                <NavBar active={this.state.active} />
                <Container className="mt-5">
                    {this.state.tweets.length !== 0 ?
                        this.state.tweets.map((tweet) => {
                            const random = Math.floor(Math.random() * this.state.profilePic.length);
                            return <div className="row justify-content-center align-self-center"><Tweet tweetInfo={tweet}  profile={this.state.profilePic[random]} history={this.props.history} isReply={false}></Tweet></div>
                        })
                        : <div className="row justify-content-center align-self-center"><p className="h4 mb-4 text-center newposttext">No Tweets Founds</p></div>
                    }
                </Container>
            </div>
        );
    }
}
export default ViewTweet;