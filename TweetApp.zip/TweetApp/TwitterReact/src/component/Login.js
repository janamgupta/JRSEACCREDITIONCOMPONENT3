import React from "react";
import { Card, Form, Button, Container, Col } from 'react-bootstrap';
import TwitterIcon from "@material-ui/icons/Twitter";
import axios from "axios";
import { Link, Redirect, useHistory } from "react-router-dom";

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userName: '', userNameValid: false,
            password: '', passwordValid: false,
            formValid: false,
            validUser: true,
            errors: {
                userName: '', password: '', validUser: ''
            }
        };
        this.handleChange.bind(this);
    }

    ValidationMessage(valid, message) {
        if (!valid) {
            return (
                <div className='error-msg'><span className='errorMsgText'>{message}</span></div>
            )
        }
        return null;
    }

    validateForm() {
        const { userNameValid, passwordValid } = this.state;
        this.setState({
            formValid: passwordValid && userNameValid
        })
    }
    userValidation(e) {
        e.preventDefault();
        axios.post('http://15.207.116.62:8092/api/v1.0/tweets/login', {
            loginId: this.state.userName,
            password: this.state.password
        })
            .then((response) => {
                if (response.data.errorMessage === null) {
                    localStorage.setItem('username', response.data.loginId);
                    localStorage.setItem('email', response.data.email)
                    localStorage.setItem('isLoggedIn', true);
                    this.props.history.push("/")
                } else {
                    let validUser = false;
                    let errors = this.state.errors;
                    errors.validUser = response.data.errorMessage;
                    this.setState({ validUser, errors });
                }
            }, (error) => {
                console.log(error);
            });
    }

    handleChange(target) {
        this.setState({ validUser: true })
        const { name, value } = target;
        const emptyRegx = RegExp(/^(?!\s*$).+/i);
        let errors = this.state.errors;
        if (name === 'userName') {
            if (!emptyRegx.test(value)) {
                errors.userName = 'user name is required';
            } else {
                errors.userName = '';
            }
            let userNameValid = false;
            if (errors.userName === '') {
                userNameValid = true;
            }
            this.setState({ userNameValid });
        } else {
            if (name === 'password') {
                if (!emptyRegx.test(value)) {
                    errors.password = 'password is required';
                } else {
                    errors.password = '';
                }
                let passwordValid = false;
                if (errors.password === '') {
                    passwordValid = true;
                }
                this.setState({ passwordValid });
            }
        }
        this.setState({ errors, [name]: value }, () => {
            this.validateForm();
        })
    }
    render() {
        return (
            <Container>
                <Card variant="border-dark" className="logincard mx-auto">
                    <TwitterIcon className="login_twitterIcon mx-auto" />
                    <Card.Body className="text-dark">
                        <Form className="loginform">
                            <p className="h4 mb-4 mt-4">Log in to Twitter</p>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="text" name="userName" className="form-control" placeholder="User Id" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} autoComplete="off" />
                                    {this.ValidationMessage(this.state.userNameValid, this.state.errors.userName)}
                                </Form.Group>
                            </Form.Row>
                            <Form.Row>
                                <Form.Group as={Col} md={12}>
                                    <input type="password" name="password" className="form-control" placeholder="Password" onChange={(e) => this.handleChange(e.target)} onFocus={(e) => this.handleChange(e.target)} />
                                    {this.ValidationMessage(this.state.passwordValid, this.state.errors.password)}
                                </Form.Group>
                            </Form.Row>
                            <div className="text-center">
                                <Button variant="outline-primary" className="my-4 signin" type="submit" disabled={!this.state.formValid} onClick={(e) => this.userValidation(e)}> SignIn </Button>
                                <Link variant="outline-primary" className="btn btn-outline-primary my-4 register" type="button" to="/register"> Register </Link>
                            </div>
                            <div className="text-center">
                                <Link to="/forgot">Forgot Password?</Link>
                            </div>
                            <h5 className="text-center">
                                {this.ValidationMessage(this.state.validUser, this.state.errors.validUser)}
                            </h5>
                        </Form>

                    </Card.Body>
                </Card>
            </Container>
        );
    }
}
export default Login;