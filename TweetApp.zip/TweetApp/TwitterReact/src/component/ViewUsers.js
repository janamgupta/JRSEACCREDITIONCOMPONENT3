import React from "react";
import NavBar from "./Nav";
import VerifiedUserIcon from "@material-ui/icons/VerifiedUser";
import Logo from '../assets/Usericon1.png';
import axios from "axios";
import { Container } from "react-bootstrap";
import Tweet from "./Tweet";
class Users extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            active: {
                main: '',
                viewTweet: '',
                viewUser: 'active',
                resetPass: '',
                myTweets: ''
            },
            users: [],
            viewTweets: false,
            tweets: []
        }
    }

    componentDidMount() {
        let isLoggedIn = localStorage.getItem("isLoggedIn");
        if (isLoggedIn === 'false') {
            this.props.history.push('/login');
        } else {
            this.getUsers();
        }
    }

    getUsers() {
        this.setState({ viewTweets: false })
        axios.get('http://15.207.116.62:8092/api/v1.0/tweets/getallUsers')
            .then((response) => {
                if (response.data !== null) {
                    const users = response.data
                    this.setState({ users })
                }
            });
    }

    getTweets(loginId) {
        axios.get('http://15.207.116.62:8092/api/v1.0/tweets/myTweet', { params: { loginId: loginId } })
            .then((response) => {
                this.setState({ tweets: response.data });
                console.log(this.state.tweets);
            }, (error) => {
                console.log(error);
            });
    }

    viewTweet(loginId) {
        this.setState({ viewTweets: true })
        this.getTweets(loginId)
    }

    formatText(value, key) {
        if (key === "name") {
            var splitStr = value.toLowerCase().split(' ');
            for (var i = 0; i < splitStr.length; i++) {
                splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
            }
            return splitStr.join(' ');
        } 
    }
    render() {
        return (
            <div>
                <NavBar active={this.state.active} />
                {this.state.viewTweets ?
                    <Container className="mt-5">
                        {this.state.tweets.length !== 0 ?
                            this.state.tweets.map((tweet) => {
                                return <div className="row justify-content-center align-self-center">
                                    <Tweet tweetInfo={tweet} profile={Logo} history={this.props.history} isReply={false}></Tweet>
                                </div>
                            })
                            : <div className="row justify-content-center align-self-center"><p className="h4 mb-4 text-center newposttext">This user dont't have any tweet.</p></div>
                        }
                        <div className="mt-5 mb-3 text-right"><button className="btn btn-outline-primary btn-md shadow-none" type="button" onClick={() => this.getUsers()}>Back</button></div>
                    </Container>
                    : this.state.users.length !== 0 ?
                        this.state.users.map((user) => {
                            if (user.loginId !== localStorage.getItem("username")) {
                                return (
                                    <div class="row justify-content-center align-self-center">
                                        <div className="card replycard mb-3">
                                            <div className="row no-gutters">
                                                <div className="col-md-4">
                                                    <img src={Logo} className="reply-avatar" />
                                                </div>
                                                <div className="col-md-7">
                                                    <div className="card-body reply-info">
                                                        <div>
                                                            <span><span>{this.formatText(user.firstName + " " + user.lastName, "name")} <VerifiedUserIcon className="verifiedUser" /></span></span>
                                                            <div>@{user.loginId}</div>
                                                            <div className="mt-5 text-center"><button className="btn btn-outline-primary btn-sm shadow-none" type="button" onClick={() => this.viewTweet(user.loginId)}>View Tweet</button></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }
                        }) : <div className="row justify-content-center align-self-center"><p className="h4 mb-4 text-center newposttext">No Users Found</p></div>}
            </div>
        );
    }
}
export default Users;