import { Twitter } from "@material-ui/icons";
import React from "react";
import { Link } from "react-router-dom";

class Error extends React.Component {
    render() {
        return (
            <div class="container">
                <div className="row error_twitter">
                    <div className="col-md-12"><Twitter className="error_twitterIcon" /></div>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        <div className="error-template">
                            <h1>
                                Oops!</h1>
                            <h2>
                                404 Not Found</h2>
                            <div className="error-details">
                                Sorry, an error has occured, Requested page not found!
                            </div>
                            <div className="error-actions">
                            <Link variant="outline-primary" className="btn btn-outline-primary" type="button" to="/"> Take Me Home </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Error;