import { Button, Container } from 'react-bootstrap';
import Tweet from "./Tweet";
import TwitterIcon from "@material-ui/icons/Twitter";
import NavBar from './Nav';
import React from 'react';
import axios from 'axios';
import Logo from '../assets/Usericon1.png';
import Logo2 from '../assets/Usericon2.png';
import Logo3 from '../assets/woman.png';

class Main extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hashTag: '',
            tweet: '',
            isValidTweet: false,
            isSuccess: true,
            random: '',
            loginId: localStorage.getItem("username"), 
            email: localStorage.getItem("email"),
            isLoggedIn: localStorage.getItem("isLoggedIn"),
            tweets:[],
            active: {
                main: 'active',
                viewTweet: '',
                viewUser: '',
                resetPass: '',
                myTweets: ''
            },
            errors: {
                tweet: '', isSuccess: ''
            },
            profilePic: [Logo, Logo2, Logo3]
        };
    }

     
    componentDidMount(){
        const random = Math.floor(Math.random() * this.state.profilePic.length);
        this.setState({random})
        this.getTweets();
    }

    getTweets(){
        axios.get('http://15.207.116.62:8092/api/v1.0/tweets/gettweets')
                .then((response) => {
                    this.setState({tweets: response.data}); 
                    console.log(this.state.tweets);
                }, (error) => {
                    console.log(error);
                });
    }
    postTweet() {
        if (this.state.isValidTweet) {
            axios.post('http://15.207.116.62:8092/api/v1.0/tweets/posttweet', {
                tweetDesc: this.state.tweet,
                tweetTag: this.state.hashTag,
                loginId: this.state.loginId,
                emailId: this.state.email
            })
                .then((response) => {
                    if (response.data === "Success") {
                        this.props.history.push("/viewTweets");
                    } else {
                        let isSuccess = false;
                        let errors = this.state.errors;
                        errors.isSuccess = "something went terribly wrong try after some time";
                        this.setState({ isSuccess, errors });
                    }
                }, (error) => {
                    console.log(error);
                });
        } else {
            let errors = this.state.errors;
            errors.tweet = "please provide tweet"
            this.setState({errors})
        }
    }

    ValidationMessage(valid, message) {
        if (!valid) {
            return (
                <div className='error-msg'><span className='errorMsgText'>{message}</span></div>
            )
        }
        return null;
    }

    isLoggedIn() {
        if (this.state.isLoggedIn === "true") {
            this.postTweet()
        } else {
            this.props.history.push("/login");
        }
    }

    handleChange(target) {
        let name = target.name;
        let value = target.value;
        let isValidTweet = true;
        let errors = this.state.errors;
        if (name === 'tweet') {
            if (value === '') {
                isValidTweet = false;
                errors.tweet = "please provide tweet"
                this.setState({ isValidTweet, [name]: value, errors})
            }else{
                this.setState({ isValidTweet, [name]: value });
            }
        }else{
            this.setState({[name]: value, errors});
        }
    }

    render() {
        return (
            <div>
                <NavBar active={this.state.active}/>
                <Container>
                    <div className="row dashboard">
                        <div className="col-sm">
                            <div className="row ml-auto"><p className="h4 mb-4 text-center newposttext">Post New Tweet</p></div>
                            <div className="row"><input placeholder="optional hash tag" className="hashText" maxLength={50} name="hashTag" onChange={(e) => this.handleChange(e.target)} /></div>
                            <div className="row"><textarea placeholder="What's happenning" className="whatshappeningtextarea" maxLength={144} name="tweet" onChange={(e) => this.handleChange(e.target)} /></div>
                            <div className="row"><Button className="btn-primary newpost" onClick={() => this.isLoggedIn()}><TwitterIcon className="posttwittericon" />Post</Button></div>
                            <div className ="row">{this.state.isValidTweet?(this.state.isSuccess?null:this.ValidationMessage(this.state.isSuccess, this.state.errors.isSuccess)):this.ValidationMessage(this.state.isValidTweet, this.state.errors.tweet)}</div>
                        </div>
                        <div className="col-sm">
                            <div className="row ml-auto"><p className="h4 mb-4 text-center newposttext">Explore</p></div>
                            {this.state.tweets.length !== 0?
                                this.state.tweets.slice(0, 5).map((tweet)=>{
                                   return <Tweet tweetInfo={tweet} profile={this.state.profilePic[this.state.random]} isReply={false} history={this.props.history}></Tweet>
                                })
                                : 
                                <div className="row ml-auto"><p className="h4 mb-4 text-center newposttext">No Tweets Founds</p></div>
                            }
                        </div>
                    </div>
                </Container>
            </div>
        );
    }
}
export default Main;