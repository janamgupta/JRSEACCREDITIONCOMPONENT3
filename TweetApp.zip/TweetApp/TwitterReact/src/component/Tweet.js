import VerifiedUserIcon from "@material-ui/icons/VerifiedUser";
import ModeCommentOutlinedIcon from '@material-ui/icons/ModeCommentOutlined';
import FavoriteBorderRoundedIcon from '@material-ui/icons/FavoriteBorderRounded';
import FavoriteRoundedIcon from '@material-ui/icons/FavoriteRounded';
import React from "react";
import Logo from '../assets/Usericon1.png';
import Logo2 from '../assets/Usericon2.png';
import Logo3 from '../assets/woman.png';
import axios from "axios";
import { FavoriteRounded } from "@material-ui/icons";
class Tweet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            tweetInfo: this.props.tweetInfo,
            isLoggedIn: localStorage.getItem("isLoggedIn"),
            isLiked: false
        };
    }

    updateLikes() {
        if (this.state.isLoggedIn === "true") {
            if(this.state.isLiked === false){
                axios.get('http://15.207.116.62:8092/api/v1.0/tweets/like', { params: { tweetId: this.state.tweetInfo.tweetId } })
                .then((response) => {
                    if(response.data === "success"){
                        this.setState({isLiked: true});
                        const tweetInfo = this.state.tweetInfo
                        tweetInfo.likes = tweetInfo.likes + 1
                        this.setState({tweetInfo});
                    }
                });
            }
        } else {
            this.props.history.push("/login");
        }
    }

    renderTweetInfo() {
        if (this.state.isLoggedIn === "true") {
            this.props.history.push({
                pathname: '/tweetInfo',
                search: `?tweetid=${this.state.tweetInfo.tweetId}`,
                state: {
                    detail: this.state.tweetInfo,
                    profile: this.props.profile,
                    isLiked: this.state.isLiked
                }
            })
        }
        else {
            this.props.history.push("/login");
        }
    }

    formatText(value, key) {
        if (key === "name") {
            var splitStr = value.toLowerCase().split(' ');
            for (var i = 0; i < splitStr.length; i++) {
                splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
            }
            return splitStr.join(' ');
        } else if (key === "date") {
            var date1 = new Date(value).getTime();
            var date2 = new Date().getTime();
            var msec = date2 - date1;
            var mins = Math.floor(msec / 60000);
            var hrs = Math.floor(mins / 60);
            var days = Math.floor(hrs / 24);
            var yrs = Math.floor(days / 365);

            if (mins < 60) {
                return mins + ' mins ago';
            } else if (mins > 60 && hrs <= 24) {
                if (hrs > 1)
                    return hrs + ' hours ago';
                else
                    return hrs + ' hour ago';
            } else {
                if (days > 1)
                    return days + ' days ago';
                else
                    return days + ' day ago';
            }
        } else if (key === "reply") {
            const repliesCount = value.length;
            return repliesCount;
        }
    }

    render() {
        return (
            <div className="card tweetcard mb-3" style={{ maxWidth: "540px" }}>
                <div className="row no-gutters">
                    <div className="col-md-4">
                        <img src={this.props.profile} className="avatar" />
                    </div>
                    <div className="col-md-7">
                        <div className="card-body tweet-info">
                            <div>
                                <span><span>{this.formatText(this.state.tweetInfo.name, "name")} <VerifiedUserIcon className="verifiedUser" /></span><span> @{this.state.tweetInfo.loginId} . {this.formatText(this.state.tweetInfo.date, "date")}</span></span>
                                <div>{this.state.tweetInfo.hashTag}</div>
                                <p>{this.state.tweetInfo.tweetDesc}</p>
                            </div>

                            <div className="tweet-icons">
                                <span><ModeCommentOutlinedIcon className="replyIcon" fontSize="small" color="action" onClick={() => this.renderTweetInfo()} />&nbsp;&nbsp;{`${this.state.tweetInfo.replies}  replies`}</span>&nbsp;&nbsp;
                                <span>{this.state.isLiked?<FavoriteRoundedIcon color="error" fontSize="small"></FavoriteRoundedIcon>:<FavoriteBorderRoundedIcon className="favIcon" fontSize="small" color="action" onClick={() => this.updateLikes()}/>}&nbsp;&nbsp;{`${this.state.tweetInfo.likes}  likes`}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Tweet;