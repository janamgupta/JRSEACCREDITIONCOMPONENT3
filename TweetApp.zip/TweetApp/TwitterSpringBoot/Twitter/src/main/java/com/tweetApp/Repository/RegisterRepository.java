package com.tweetApp.Repository;

import java.util.List;
import java.util.Optional;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetApp.Model.Register;

@EnableScan
@Repository
public interface RegisterRepository extends CrudRepository<Register,String> {
	
	Optional<Register> findByemail(String email);
	
	List<Register> findAll();

}
