package com.tweetApp.Repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetApp.Model.Register;

@Repository
@EnableScan
public interface UserRepository extends CrudRepository<Register,String> {
	
	Register findByEmail(String email);
	
	Register findByLoginId(String loginId);
	

}
